<?php

	$conn= new mysqli("localhost","id14727958_vsnallapati","Narutogym@123","id14727958_members");
	if($conn->connect_error)
	{
	  	echo 'Cant connect to database';
	}			
?>